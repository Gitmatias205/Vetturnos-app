package com.tuempresa.vetturnos

class FirebaseStorage {
    companion object

}
