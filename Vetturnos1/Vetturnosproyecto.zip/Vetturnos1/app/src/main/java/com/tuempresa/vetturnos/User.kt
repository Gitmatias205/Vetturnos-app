package com.tuempresa.vetturnos

data class User(
    val correo: String,
    val rol: String,
    val clave: String
)
